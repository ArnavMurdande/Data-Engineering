CREATE TABLE dbo.department_id (department_id VARCHAR(40) NOT NULL PRIMARY KEY, display_name VARCHAR(100), region VARCHAR(20), active_flag CHAR(1), effective_date DATE, risk_tier VARCHAR(10));
-- Import datasets/azure_sql_extracts/department_id.csv into dbo.department_id using Azure SQL import tools or an approved ingestion process.
CREATE TABLE dbo.patient_id (patient_id VARCHAR(40) NOT NULL PRIMARY KEY, display_name VARCHAR(100), region VARCHAR(20), active_flag CHAR(1), effective_date DATE, risk_tier VARCHAR(10));
-- Import datasets/azure_sql_extracts/patient_id.csv into dbo.patient_id using Azure SQL import tools or an approved ingestion process.
